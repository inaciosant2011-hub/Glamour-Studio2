import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Phone, Clock, Star, Scissors, Sparkles, Heart, Users } from "lucide-react"
import Image from "next/image"

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Image src="/images/glamour-logo.png" alt="Glamour Studio" width={60} height={60} className="rounded-lg" />
            <div>
              <h1 className="font-serif text-xl font-bold text-primary">Glamour Studio</h1>
              <p className="text-sm text-muted-foreground">Salão de Beleza</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <a href="#servicos" className="text-foreground hover:text-primary transition-colors">
              Serviços
            </a>
            <a href="#sobre" className="text-foreground hover:text-primary transition-colors">
              Sobre
            </a>
            <a href="#contato" className="text-foreground hover:text-primary transition-colors">
              Contato
            </a>
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Agendar Horário</Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-4 text-center">
        <div className="container mx-auto max-w-4xl">
          <div className="mb-8">
            <Image
              src="/images/glamour-logo.png"
              alt="Glamour Studio Logo"
              width={200}
              height={200}
              className="mx-auto mb-6 rounded-2xl shadow-2xl"
            />
          </div>
          <h2 className="font-serif text-4xl md:text-6xl font-bold mb-6 text-foreground">
            Sua Beleza é Nossa <span className="text-primary">Paixão</span>
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            No Glamour Studio, transformamos sua beleza com técnicas modernas e atendimento personalizado no coração de
            Camaquã.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Sparkles className="mr-2 h-5 w-5" />
              Agendar Consulta
            </Button>
            <Button size="lg" variant="outline">
              <Phone className="mr-2 h-5 w-5" />
              Entrar em Contato
            </Button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="servicos" className="py-20 px-4 bg-card">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h3 className="font-serif text-3xl md:text-4xl font-bold mb-4 text-card-foreground">Nossos Serviços</h3>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Uma nova proposta em beleza com serviços especializados e atendimento personalizado para realçar sua
              beleza natural.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Scissors className="h-8 w-8" />,
                title: "Cabeleireira",
                description: "Cortes modernos, escova, penteados e tratamentos capilares profissionais",
                price: "A partir de R$ 60",
              },
              {
                icon: <Sparkles className="h-8 w-8" />,
                title: "Manicure",
                description: "Cuidados completos para suas unhas com esmaltação perfeita e duradoura",
                price: "A partir de R$ 35",
              },
              {
                icon: <Heart className="h-8 w-8" />,
                title: "Design de Sobrancelha",
                description: "Modelagem e design personalizado para valorizar seu olhar",
                price: "A partir de R$ 40",
              },
              {
                icon: <Users className="h-8 w-8" />,
                title: "Sobrancelha",
                description: "Depilação, correção e finalização para sobrancelhas perfeitas",
                price: "A partir de R$ 25",
              },
            ].map((service, index) => (
              <Card key={index} className="group hover:shadow-lg transition-all duration-300 border-border">
                <CardContent className="p-6 text-center">
                  <div className="text-primary mb-4 flex justify-center group-hover:scale-110 transition-transform">
                    {service.icon}
                  </div>
                  <h4 className="font-serif text-xl font-semibold mb-3 text-card-foreground">{service.title}</h4>
                  <p className="text-muted-foreground mb-4">{service.description}</p>
                  <Badge variant="secondary" className="bg-primary/10 text-primary">
                    {service.price}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="sobre" className="py-20 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <h3 className="font-serif text-3xl md:text-4xl font-bold mb-8 text-foreground">Sobre o Glamour Studio</h3>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="text-left">
              <p className="text-lg text-muted-foreground mb-6">
                O Glamour Studio é uma nova proposta em beleza que chega a Camaquã com serviços especializados e
                atendimento personalizado. Nossa equipe de profissionais qualificados está sempre atualizada com as
                últimas tendências e técnicas.
              </p>
              <div className="flex items-center space-x-4 mb-4">
                <Star className="h-5 w-5 text-primary fill-current" />
                <span className="text-foreground">Atendimento personalizado e de qualidade</span>
              </div>
              <div className="flex items-center space-x-4 mb-4">
                <Sparkles className="h-5 w-5 text-primary" />
                <span className="text-foreground">Produtos premium e técnicas modernas</span>
              </div>
              <div className="flex items-center space-x-4">
                <Heart className="h-5 w-5 text-primary" />
                <span className="text-foreground">Ambiente acolhedor no centro da cidade</span>
              </div>
            </div>
            <div className="relative">
              <div className="bg-primary/10 rounded-2xl p-8 text-center">
                <div className="text-4xl font-bold text-primary mb-2">NOVO</div>
                <div className="text-muted-foreground">Salão em Camaquã</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contato" className="py-20 px-4 bg-card">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-16">
            <h3 className="font-serif text-3xl md:text-4xl font-bold mb-4 text-card-foreground">Visite-nos</h3>
            <p className="text-lg text-muted-foreground">
              Estamos localizados no centro de Camaquã, com fácil acesso e estacionamento.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <Card className="border-border">
              <CardContent className="p-8">
                <h4 className="font-serif text-2xl font-semibold mb-6 text-card-foreground">Informações de Contato</h4>

                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <MapPin className="h-6 w-6 text-primary mt-1" />
                    <div>
                      <p className="font-semibold text-card-foreground">Endereço</p>
                      <p className="text-muted-foreground">
                        Rua Julio de Castilhos, 824
                        <br />
                        Centro - Camaquã, RS
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <Phone className="h-6 w-6 text-primary mt-1" />
                    <div>
                      <p className="font-semibold text-card-foreground">Telefone</p>
                      <p className="text-muted-foreground">(51) 9999-9999</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <Clock className="h-6 w-6 text-primary mt-1" />
                    <div>
                      <p className="font-semibold text-card-foreground">Horário de Funcionamento</p>
                      <div className="text-muted-foreground">
                        <p>Segunda a Sexta: 8h às 18h</p>
                        <p>Sábado: 8h às 16h</p>
                        <p>Domingo: Fechado</p>
                      </div>
                    </div>
                  </div>
                </div>

                <Button className="w-full mt-8 bg-primary text-primary-foreground hover:bg-primary/90">
                  <Phone className="mr-2 h-5 w-5" />
                  Agendar pelo WhatsApp
                </Button>
              </CardContent>
            </Card>

            <div className="bg-muted/20 rounded-lg p-8 flex items-center justify-center">
              <div className="text-center">
                <MapPin className="h-16 w-16 text-primary mx-auto mb-4" />
                <h4 className="font-serif text-xl font-semibold mb-2 text-card-foreground">Localização Privilegiada</h4>
                <p className="text-muted-foreground">
                  No coração de Camaquã, com fácil acesso e próximo aos principais pontos da cidade.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t border-border">
        <div className="container mx-auto max-w-4xl text-center">
          <div className="flex items-center justify-center space-x-2 mb-6">
            <Image src="/images/glamour-logo.png" alt="Glamour Studio" width={40} height={40} className="rounded-lg" />
            <div>
              <h5 className="font-serif text-lg font-bold text-primary">Glamour Studio</h5>
              <p className="text-sm text-muted-foreground">Salão de Beleza</p>
            </div>
          </div>

          <p className="text-muted-foreground mb-4">Rua Julio de Castilhos, 824 - Centro, Camaquã - RS</p>

          <div className="flex justify-center space-x-6 mb-6">
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
              Instagram
            </a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
              Facebook
            </a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
              WhatsApp
            </a>
          </div>

          <p className="text-sm text-muted-foreground">© 2024 Glamour Studio. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  )
}
